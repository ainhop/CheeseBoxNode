-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 02-06-2021 a las 18:11:37
-- Versión del servidor: 10.4.19-MariaDB
-- Versión de PHP: 8.0.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `cheesebox`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `int(11)`
--

CREATE TABLE `int(11)` (
  `id` int(11) NOT NULL,
  `nombre` varchar(100) DEFAULT NULL,
  `descripcion` mediumtext DEFAULT NULL,
  `tiempo` time DEFAULT NULL,
  `queso_utilizado` enum('mozarella','edam','brie','suizo','camembert','feta','roquefort','crema') DEFAULT NULL,
  `raciones` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `productos`
--

CREATE TABLE `productos` (
  `id` int(11) NOT NULL,
  `nombre` varchar(60) DEFAULT NULL,
  `descripcion` mediumtext NOT NULL,
  `tipo_leche` enum('vaca','oveja','burra','tres_leches','vegetal') DEFAULT NULL,
  `origen` varchar(45) DEFAULT NULL,
  `caracteristicas` mediumtext DEFAULT NULL,
  `color` varchar(45) DEFAULT NULL,
  `tipo` enum('mozarella','edam','brie','suizo','camembert','feta','roquefort','crema') DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `recetas`
--

CREATE TABLE `recetas` (
  `id` int(11) NOT NULL,
  `nombre` varchar(100) DEFAULT NULL,
  `descripcion` mediumtext DEFAULT NULL,
  `tiempo` time DEFAULT NULL,
  `queso_utilizado` int(11) DEFAULT NULL,
  `raciones` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tbi_clientes_quesos`
--

CREATE TABLE `tbi_clientes_quesos` (
  `id` int(11) NOT NULL,
  `tb_fk_clientes_quesos` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tbi_usuario_recetas`
--

CREATE TABLE `tbi_usuario_recetas` (
  `id` int(11) NOT NULL,
  `tbi_usuario_recetas` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tb_productos_recetas`
--

CREATE TABLE `tb_productos_recetas` (
  `id` int(11) NOT NULL,
  `tb_fk_productos_recetas` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE `usuarios` (
  `id` int(11) NOT NULL,
  `nombre` varchar(60) DEFAULT NULL,
  `apellidos` varchar(60) DEFAULT NULL,
  `username` varchar(45) DEFAULT NULL,
  `usuarioscol` varchar(60) DEFAULT NULL,
  `email` varchar(90) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `imagen` varchar(255) DEFAULT NULL,
  `fk_queso` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `int(11)`
--
ALTER TABLE `int(11)`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_recetas_tb_productos_recetas1_idx` (`queso_utilizado`);

--
-- Indices de la tabla `productos`
--
ALTER TABLE `productos`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `recetas`
--
ALTER TABLE `recetas`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_recetas_tb_productos_recetas1_idx` (`queso_utilizado`);

--
-- Indices de la tabla `tbi_clientes_quesos`
--
ALTER TABLE `tbi_clientes_quesos`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `tbi_usuario_recetas`
--
ALTER TABLE `tbi_usuario_recetas`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_tbi_usuario_recetas_recetas1_idx` (`tbi_usuario_recetas`);

--
-- Indices de la tabla `tb_productos_recetas`
--
ALTER TABLE `tb_productos_recetas`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_usuarios_tbi_usuario_recetas1_idx` (`fk_queso`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `int(11)`
--
ALTER TABLE `int(11)`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `recetas`
--
ALTER TABLE `recetas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `tbi_usuario_recetas`
--
ALTER TABLE `tbi_usuario_recetas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `recetas`
--
ALTER TABLE `recetas`
  ADD CONSTRAINT `fk_recetas_tb_productos_recetas1` FOREIGN KEY (`queso_utilizado`) REFERENCES `tb_productos_recetas` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
